import pygame
import sys

# Initialize pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 600, 600
LINE_WIDTH = 15
BOARD_ROWS, BOARD_COLS = 3, 3
SQUARE_SIZE = WIDTH // BOARD_COLS

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
LINE_COLOR = (23, 145, 135)

# Initialize screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tic Tac Toe")

# Load images
X_IMAGE = pygame.image.load("creative-wrong-icon-3d-render-png.webp")
O_IMAGE = pygame.image.load("130341-letter-o-free-download-png-hd.png")
X_IMAGE = pygame.transform.scale(X_IMAGE, (SQUARE_SIZE, SQUARE_SIZE))
O_IMAGE = pygame.transform.scale(O_IMAGE, (SQUARE_SIZE, SQUARE_SIZE))

# Fonts
END_FONT = pygame.font.SysFont('courier', 40)

# Function to draw grid lines
def draw_lines():
    # Vertical lines
    pygame.draw.line(screen, LINE_COLOR, (SQUARE_SIZE, 0), (SQUARE_SIZE, HEIGHT), LINE_WIDTH)
    pygame.draw.line(screen, LINE_COLOR, (2 * SQUARE_SIZE, 0), (2 * SQUARE_SIZE, HEIGHT), LINE_WIDTH)
    # Horizontal lines
    pygame.draw.line(screen, LINE_COLOR, (0, SQUARE_SIZE), (WIDTH, SQUARE_SIZE), LINE_WIDTH)
    pygame.draw.line(screen, LINE_COLOR, (0, 2 * SQUARE_SIZE), (WIDTH, 2 * SQUARE_SIZE), LINE_WIDTH)

# Function to draw X and O
def draw_figures():
    for row in range(BOARD_ROWS):
        for col in range(BOARD_COLS):
            if board[row][col] == 'X':
                screen.blit(X_IMAGE, (col * SQUARE_SIZE, row * SQUARE_SIZE))
            elif board[row][col] == 'O':
                screen.blit(O_IMAGE, (col * SQUARE_SIZE, row * SQUARE_SIZE))

# Function to mark the cell clicked by the player
def mark_square(row, col, player):
    board[row][col] = player

# Function to check for a win
def check_win(player):
    # Check rows
    for row in range(BOARD_ROWS):
        if all(board[row][col] == player for col in range(BOARD_COLS)):
            return True
    # Check columns
    for col in range(BOARD_COLS):
        if all(board[row][col] == player for row in range(BOARD_ROWS)):
            return True
    # Check diagonals
    if all(board[i][i] == player for i in range(BOARD_ROWS)):
        return True
    if all(board[i][BOARD_COLS - 1 - i] == player for i in range(BOARD_ROWS)):
        return True
    return False

# Function to check if the board is full
def check_draw():
    for row in range(BOARD_ROWS):
        for col in range(BOARD_COLS):
            if board[row][col] == ' ':
                return False
    return True

# Function to display game over screen
def show_game_over(winner):
    end_text = "Draw!" if winner == 'draw' else f"{winner} wins!"
    end_surf = END_FONT.render(end_text, True, WHITE)
    screen.blit(end_surf, ((WIDTH - end_surf.get_width()) // 2, (HEIGHT - end_surf.get_height()) // 2))
    pygame.display.flip()
    pygame.time.wait(3000)

# Initialize board
board = [[' ' for _ in range(BOARD_COLS)] for _ in range(BOARD_ROWS)]
player_turn = 'X'
game_over = False

# Game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN and not game_over:
            mouseX = event.pos[0]  # x coordinate of mouse click
            mouseY = event.pos[1]  # y coordinate of mouse click

            clicked_row = mouseY // SQUARE_SIZE
            clicked_col = mouseX // SQUARE_SIZE

            if board[clicked_row][clicked_col] == ' ':
                mark_square(clicked_row, clicked_col, player_turn)
                if check_win(player_turn):
                    game_over = True
                elif check_draw():
                    game_over = True
                player_turn = 'O' if player_turn == 'X' else 'X'

        if game_over:
            show_game_over(player_turn if not check_draw() else 'draw')
            board = [[' ' for _ in range(BOARD_COLS)] for _ in range(BOARD_ROWS)]
            player_turn = 'X'
            game_over = False

    # Background color
    screen.fill(BLACK)
    draw_lines()
    draw_figures()
    pygame.display.flip()
